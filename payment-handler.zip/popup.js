// Popup script for Resume Tailor extension

// Get API URL from config, storage, or use default
let API_BASE_URL = (typeof EXTENSION_CONFIG !== 'undefined' && EXTENSION_CONFIG.API_BASE_URL) 
  ? EXTENSION_CONFIG.API_BASE_URL 
  : 'https://onpagecv.on-forge.com';

// Helper to get API base URL (always adds /api if not present)
function getApiBaseUrl() {
  const base = API_BASE_URL.endsWith('/api') ? API_BASE_URL : API_BASE_URL + '/api';
  return base;
}

// DOM Elements
const authSection = document.getElementById('auth-section');
const uploadSection = document.getElementById('upload-section');
const readySection = document.getElementById('ready-section');
const tailorSection = document.getElementById('tailor-section');
const resultsSection = document.getElementById('results-section');
const errorSection = document.getElementById('error-section');

const uploadBox = document.getElementById('upload-box');
const resumeFileInput = document.getElementById('resume-file');
const uploadBtn = document.getElementById('upload-btn');
const uploadStatus = document.getElementById('upload-status');

const jobText = document.getElementById('job-text');
// Wrap in try-catch to catch any errors during element selection
let tailorBtn, loading;
try {
  tailorBtn = document.getElementById('tailor-btn');
  loading = document.getElementById('loading');
  
  // IMMEDIATELY hide loading element - never show it automatically
  if (loading) {
    loading.classList.add('hidden');
  }
} catch (error) {
  // Silently handle error
}

const fullDocumentContent = document.getElementById('full-document-content');
const coverLetterContent = document.getElementById('cover-letter-content');

// Expanded editor elements
const expandedEditorOverlay = document.getElementById('expanded-editor-overlay');
const expandedEditorText = document.getElementById('expanded-editor-text');
const expandedEditorTitle = document.getElementById('expanded-editor-title');
const expandedEditorClose = document.getElementById('expanded-editor-close');
const expandedEditorSave = document.getElementById('expanded-editor-save');
const expandedEditorCancel = document.getElementById('expanded-editor-cancel');
const expandedEditorToolbar = document.getElementById('expanded-editor-toolbar');

// Rich text editor instance
let currentEditorTarget = null; // 'resume' or 'cover-letter'

// Helper function to convert HTML to plain text with proper line breaks
function convertHtmlToPlainText(element) {
  let text = '';
  const nodes = element.childNodes;
  
  for (let i = 0; i < nodes.length; i++) {
    const node = nodes[i];
    
    if (node.nodeType === Node.TEXT_NODE) {
      text += node.textContent;
    } else if (node.nodeType === Node.ELEMENT_NODE) {
      const tagName = node.tagName.toLowerCase();
      
      // Handle line breaks
      if (tagName === 'br') {
        text += '\n';
      } else if (tagName === 'p' || tagName === 'div') {
        if (i > 0) text += '\n\n';
        text += convertHtmlToPlainText(node);
      } else if (tagName === 'li') {
        text += '• ' + convertHtmlToPlainText(node) + '\n';
      } else if (tagName === 'ul' || tagName === 'ol') {
        text += convertHtmlToPlainText(node);
      } else {
        // For other tags (b, i, strong, etc.), just get the text content
        text += convertHtmlToPlainText(node);
      }
    }
  }
  
  return text.trim();
}

const newTailorBtn = document.getElementById('new-tailor-btn');
const errorMessage = document.getElementById('error-message');
const retryBtn = document.getElementById('retry-btn');

// Standard API response handler
// Helper function to check if an error is an authentication error (401/403) vs network error
function isAuthenticationError(error) {
  if (!error) return false;
  
  const errorMessage = error.message || '';
  const errorString = error.toString();
  
  // Check for HTTP status codes in error message
  if (errorMessage.includes('401') || errorMessage.includes('Unauthorized')) {
    return true;
  }
  if (errorMessage.includes('403') || errorMessage.includes('Forbidden')) {
    return true;
  }
  
  // Check if error has status property
  if (error.status === 401 || error.status === 403) {
    return true;
  }
  
  // Check if error response indicates auth failure
  if (error.response && (error.response.status === 401 || error.response.status === 403)) {
    return true;
  }
  
  // Network errors should not trigger logout
  if (errorMessage.includes('Network error') || 
      errorMessage.includes('Failed to fetch') ||
      errorMessage.includes('timeout') ||
      errorMessage.includes('NetworkError') ||
      errorMessage.includes('ERR_INTERNET_DISCONNECTED') ||
      errorMessage.includes('ERR_NETWORK_CHANGED') ||
      errorMessage.includes('ERR_CONNECTION_REFUSED') ||
      errorMessage.includes('ERR_CONNECTION_RESET') ||
      errorMessage.includes('ERR_CONNECTION_TIMED_OUT')) {
    return false;
  }
  
  // Default: if we can't determine, assume it's not an auth error (safer to keep user logged in)
  return false;
}

// Verify auth with retry logic for network errors
async function verifyAuthWithRetry(maxRetries = 2, retryDelay = 1000) {
  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      const response = await window.apiRequest('/me');
      return response;
    } catch (error) {
      // If it's an authentication error, don't retry
      if (isAuthenticationError(error)) {
        throw error;
      }
      
      // If it's a network error and we have retries left, wait and retry
      if (attempt < maxRetries) {
        
        await new Promise(resolve => setTimeout(resolve, retryDelay));
        continue;
      }
      
      // All retries exhausted, return null to indicate network error (but not auth error)
      
      return null;
    }
  }
  return null;
}

async function apiRequest(endpoint, options = {}) {
  const requestStartTime = Date.now();
  let url = getApiBaseUrl() + endpoint;
  
  try {
    // Get auth token from storage
    const { authToken } = await chrome.storage.local.get(['authToken']);
    
    // Add ngrok-skip-browser-warning header for ngrok free tier
    const headers = {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      ...options.headers,
    };
    
    // Add Authorization header if token exists
    if (authToken) {
      headers['Authorization'] = `Bearer ${authToken}`;
    }
    
    // Check if URL is ngrok and add skip warning header (always add for ngrok)
    if (url.includes('ngrok-free.app') || url.includes('ngrok-free.dev') || url.includes('ngrok.io') || url.includes('ngrok')) {
      headers['ngrok-skip-browser-warning'] = 'true';
      // Also add as query parameter AFTER the endpoint (not in base URL)
      if (!url.includes('ngrok-skip-browser-warning')) {
        url += (url.includes('?') ? '&' : '?') + 'ngrok-skip-browser-warning=true';
      }
    }
    
    const fetchStartTime = Date.now();
    
    // Create abort controller for timeout
    const controller = new AbortController();
    const timeoutId = setTimeout(() => {
      controller.abort();
    }, 60000); // 60 second timeout
    
    let response;
    try {
      response = await fetch(url, {
        ...options,
        headers: headers,
        signal: controller.signal,
      });
      clearTimeout(timeoutId);
    } catch (error) {
      clearTimeout(timeoutId);
      if (error.name === 'AbortError') {
        throw new Error('Request timeout: The server took too long to respond. Check if your backend is running.');
      }
      throw error;
    }
    
    const fetchDuration = Date.now() - fetchStartTime;
    
    // Use centralized response parsing if available
    let data;
    
    if (window.API_CONFIG) {
      // Use centralized parsing
      try {
        data = await window.API_CONFIG.parseResponse(response);
      } catch (parseError) {
        // parseResponse throws error for HTML, re-throw it
        throw parseError;
      }
    } else {
      // Fallback: manual parsing
    const contentType = response.headers.get('content-type');
    
    if (contentType && contentType.includes('application/json')) {
      data = await response.json();
    } else {
      // Got HTML instead of JSON (likely an error page)
      const text = await response.text();
      
      // Check if it's ngrok warning page
      let errorMsg = `API endpoint returned HTML instead of JSON.\n\n`;
      errorMsg += `URL: ${url}\n\n`;
      
      if (text.includes('ngrok') || text.includes('You have been denied access')) {
        errorMsg += `⚠️ This appears to be the ngrok warning page.\n\n`;
        errorMsg += `Solutions:\n`;
          errorMsg += `1. Make sure your backend is running: npm run dev (Node.js) or php artisan serve (Laravel)\n`;
          errorMsg += `2. Verify ngrok is pointing to the correct port (3000 for Node.js, 8000 for Laravel)\n`;
        errorMsg += `3. Try accessing ${url} directly in your browser\n`;
        errorMsg += `4. Check browser console (F12) for CORS errors\n`;
      } else if (text.includes('404') || text.includes('Not Found')) {
        errorMsg += `⚠️ 404 Not Found - The endpoint doesn't exist.\n\n`;
          errorMsg += `Check:\n1. Backend routes are correct\n2. Backend server is running (Node.js or Laravel)\n3. API prefix is /api\n`;
      } else if (text.includes('500') || text.includes('Internal Server Error')) {
        errorMsg += `⚠️ 500 Server Error - Backend has an error.\n\n`;
          errorMsg += `Check:\n1. Backend logs (check terminal where server is running)\n`;
          errorMsg += `2. Server errors in console\n`;
          errorMsg += `3. All dependencies installed: npm install (Node.js) or composer install (Laravel)\n`;
      } else {
        errorMsg += `This might be:\n`;
        errorMsg += `- ngrok warning/interstitial page\n`;
        errorMsg += `- Laravel error page\n`;
        errorMsg += `- Backend not accessible\n\n`;
        errorMsg += `Try:\n1. Test API directly: ${url}\n`;
          errorMsg += `2. Check backend is running: npm run dev (in backend2 folder)\n`;
        errorMsg += `3. Verify ngrok tunnel is active\n`;
      }
      
      throw new Error(errorMsg);
      }
    }

    // Standard response format: { success: bool, data: any, message: string, error: string }
    if (!response.ok) {
      // Preserve status code in error for authentication checks
      const apiError = new Error(data.error || data.message || `Request failed with status ${response.status}`);
      apiError.status = response.status;
      apiError.response = { status: response.status };
      throw apiError;
    }

    return data;
  } catch (error) {
    if (error.message && error.message.includes('API endpoint returned HTML')) {
      throw error; // Re-throw our custom error
    }
    
    // Preserve status code if available
    const networkError = new Error(error.message || 'Network error occurred. Check your API URL and ensure backend is running.');
    if (error.status) {
      networkError.status = error.status;
    }
    if (error.response) {
      networkError.response = error.response;
    }
    throw networkError;
  }
}

// Initialize popup
async function init() {

  // IMPORTANT: Hide all sections initially to prevent flash
  // Hide auth section by default (it's already hidden in HTML)
  authSection.classList.add('hidden');
  uploadSection.classList.add('hidden');
  readySection.classList.add('hidden');
  tailorSection.classList.add('hidden');
  resultsSection.classList.add('hidden');
  errorSection.classList.add('hidden');
  
  // IMPORTANT: Hide loading immediately on init - never show it automatically
  if (loading) {
    loading.classList.add('hidden');

  }
  
  // Load API URL from config.js (no storage needed - set by developer)
  // API_BASE_URL is already set from config.js at the top of the file

  // PRIORITY 1: Check for selected text from context menu FIRST (before auth check)
  // This ensures new job descriptions are handled immediately without delay
  const { selectedJobDescription } = await chrome.storage.local.get(['selectedJobDescription']);
  if (selectedJobDescription) {

    // Show tailor section immediately with job description (don't wait for auth)
    jobText.textContent = selectedJobDescription;
    window.showTailorSection();
    // Don't remove selectedJobDescription yet - keep it until generation starts
    // This ensures it's available if the user clicks generate before it's displayed
    
    // Clear old results state
    await chrome.storage.local.set({
      currentSection: 'tailor',
      operationState: null,
      pendingJobDescription: null,
    });
    
    // Show a brief loading indicator while checking auth (small, non-intrusive)
    const loadingText = document.createElement('div');
    loadingText.id = 'auth-checking';
    loadingText.style.cssText = 'text-align: center; padding: 5px; color: #9ca3af; font-size: 11px; margin-bottom: 10px;';
    loadingText.textContent = 'Verifying...';
    const tailorContent = tailorSection.querySelector('.section-content') || tailorSection;
    tailorContent.insertBefore(loadingText, tailorContent.firstChild);
    
    // Check authentication in background (non-blocking)
    const { authToken, user } = await chrome.storage.local.get(['authToken', 'user']);
    
    if (!authToken) {
      // No auth token - remove loading text and show auth
      if (loadingText.parentNode) loadingText.remove();
      window.showAuthSection();
      return;
    }
    
    // If we have a token, show user info immediately (optimistic UI)
    if (user) {
      window.updateUserInfo(user);
    }
    
    // Verify token in background (non-blocking for UI)
    window.apiRequest('/me').then(response => {
      // Remove loading text
      if (loadingText.parentNode) loadingText.remove();
      
      if (response.success) {
        chrome.storage.local.set({ user: response.data.user });
        window.updateUserInfo(response.data.user);

        // Load credits after authentication
        if (window.loadCredits) {
          window.loadCredits().catch(() => {});
        }
      } else {
        // Token invalid, show auth
        chrome.storage.local.remove(['authToken', 'user']);
        window.showAuthSection();
      }
    }).catch(error => {

      // Remove loading text
      if (loadingText.parentNode) loadingText.remove();
      // Only log out if it's an actual authentication error, not a network error
      if (isAuthenticationError(error)) {
      chrome.storage.local.remove(['authToken', 'user']);
      window.showAuthSection();
      } else {
        // Network error - keep user logged in, just log the error

      }
    });
    
    // Enable button immediately (user can see the job description)
    if (tailorBtn) {
      tailorBtn.disabled = false;
    }
    return;
  }
  
  // PRIORITY 2: Check authentication (only if no selected job description)
  const { authToken, user } = await chrome.storage.local.get(['authToken', 'user']);
  
  if (!authToken) {

    window.showAuthSection();
    return;
  }
  
  // If we have a token, show user info immediately (optimistic UI)
  if (user) {
    window.updateUserInfo(user);
  }
  
  // Verify token is still valid (async check with retry for network errors)
  try {
    const response = await verifyAuthWithRetry();
    if (response && response.success) {
      // Token is valid, update user info
      await chrome.storage.local.set({ user: response.data.user });
      window.updateUserInfo(response.data.user);

      // Load credits
      if (window.loadCredits) {
        await window.loadCredits();
      }
    } else if (response && !response.success) {
      // Token invalid, show auth
      await chrome.storage.local.remove(['authToken', 'user']);
      window.showAuthSection();
      return;
    }
    // If response is null, it was a network error and we're keeping user logged in
  } catch (error) {

    // Only log out if it's an actual authentication error
    if (isAuthenticationError(error)) {
    await chrome.storage.local.remove(['authToken', 'user']);
    window.showAuthSection();
    return;
    } else {
      // Network error - keep user logged in

    }
  }
  
  // Check if there's an operation in progress or saved state
  const { 
    operationState, 
    resumeId, 
    pendingJobDescription,
    currentSection,
    lastResults,
    lastViewedAt,
    savedJobDescription
  } = await chrome.storage.local.get([
    'operationState', 
    'resumeId',
    'pendingJobDescription',
    'currentSection',
    'lastResults',
    'lastViewedAt',
    'savedJobDescription'
  ]);

  // Check if generation is in progress - check both StateManager and operationState
  let generationInProgress = false;
  let jobDescriptionToRestore = null;
  
  // First try StateManager if available
  if (window.StateManager && typeof window.StateManager.restoreGenerationState === 'function') {
    try {
      const generationState = await window.StateManager.restoreGenerationState();
      if (generationState && generationState.inProgress) {
        generationInProgress = true;
        jobDescriptionToRestore = generationState.jobDescription;
      }
    } catch (error) {

    }
  }
  
  // Also check operationState directly as fallback
  if (!generationInProgress && operationState === 'tailoring') {
    const { generationStartTime, jobDescription: storedJobDescription } = await chrome.storage.local.get(['generationStartTime', 'jobDescription']);
    const elapsed = generationStartTime ? (Date.now() - generationStartTime) : 0;
    
    // If generation started less than 5 minutes ago, consider it in progress
    if (elapsed < 5 * 60 * 1000) {
      generationInProgress = true;
      jobDescriptionToRestore = pendingJobDescription || storedJobDescription;
    } else {
      // Stale state - clear it

      await chrome.storage.local.set({ operationState: null, generationStartTime: null });
    }
  }
  
  // If generation is in progress, restore the loading state
  if (generationInProgress && jobDescriptionToRestore) {

        if (jobText) {
      jobText.textContent = jobDescriptionToRestore;
        }
        window.showTailorSection();
        
        // Show loading overlay
        if (loading) {
          loading.classList.remove('hidden');
          if (typeof window.startLoadingMessages === 'function') {
            window.startLoadingMessages();
          }
        }
        
    // Disable the generate button while in progress
    if (tailorBtn) {
      tailorBtn.disabled = true;
    }
    
    // Note: The actual API request may still be in progress on the backend
    // The user can see the loading state, and if they wait, results will appear
    // If the request already completed, they may need to refresh or check results
        return;
  }

  // Only restore results if:
  // 1. No operation is in progress
  // 2. Results section was the last viewed section
  // 3. Results exist and were viewed recently (within 24 hours)
  // 4. User is not starting a new tailoring operation (no pending job description)
  // 5. User has a resume (not a new account)
  const shouldRestoreResults = 
    !operationState && // No active operation
    currentSection === 'results' && // Was viewing results
    lastResults && // Results exist
    lastViewedAt && // Has timestamp
    (Date.now() - lastViewedAt < 86400000) && // Within 24 hours
    !pendingJobDescription && // Not starting a new tailoring
    resumeId; // User has a resume (not a new account)
  
  // After login, prioritize home page (unless there's a selected job description)
  // Only show upload if no resume exists (new account)
  
  // Check for selected job description first (highest priority)
  const { selectedJobDescription: checkSelected } = await chrome.storage.local.get(['selectedJobDescription']);
  if (checkSelected) {
    // New job description selected - show tailor section

    jobText.textContent = checkSelected;
      window.showTailorSection();
    chrome.storage.local.remove(['selectedJobDescription']);
      if (loading) {
        loading.classList.add('hidden');
      }
      if (tailorBtn) {
        tailorBtn.disabled = false;
      }
    return;
  }
  
  // Only restore results if:
  // 1. Explicitly viewing results (not after login)
  // 2. User has a resume (not a new account)
  // 3. Results belong to current user's resume
  if (shouldRestoreResults && currentSection === 'results' && resumeId) {
    // Verify the resumeId matches before restoring results
    // This prevents showing old results from a different account
    const { resumeId: storedResumeId } = await chrome.storage.local.get(['resumeId']);
    if (storedResumeId === resumeId) {

      await displayResults(lastResults);
      window.showResultsSection();
      return;
    } else {
      // Resume ID mismatch - clear old results

      await chrome.storage.local.remove(['lastResults', 'currentSection']);
    }
  }
  
  // Clear any stale operation state after login
  if (operationState === 'tailoring' || operationState === 'uploading') {
    await chrome.storage.local.set({ 
      operationState: null,
      pendingJobDescription: null
    });
  }
  
  if (resumeId) {
    // Normal state - resume uploaded, show home page
    // Only show tailor section if there's a new selected job description
    const { selectedJobDescription: checkSelected } = await chrome.storage.local.get(['selectedJobDescription']);
    if (checkSelected) {
      // New job description selected - show tailor section

      await chrome.storage.local.set({
        currentSection: 'tailor',
        operationState: null,
        pendingJobDescription: null,
      });
      
      jobText.textContent = checkSelected;
      window.showTailorSection();
      chrome.storage.local.remove(['selectedJobDescription']);
      
      if (loading) {
        loading.classList.add('hidden');
      }
      if (tailorBtn) {
        tailorBtn.disabled = false;
      }
    } else {
      // No new selection - show home page (ready section)

      window.showReadySection();
      loadResumeInfo(); // Load and display stats
    }
  } else {
    // No resumeId in storage - try to fetch default resume from API

    try {
      const { authToken } = await chrome.storage.local.get(['authToken']);
      if (!authToken) {
        window.showAuthSection();
        return;
      }

      const response = await window.apiRequest('/resume');

      if (response.success && response.data) {
        const resumeId = response.data.resumeId;

        if (resumeId) {
          // Save resumeId to storage
          await chrome.storage.local.set({
            resumeId: resumeId,
            resumeFilename: response.data.filename,
            resumeCloudinaryUrl: response.data.cloudinaryUrl,
            resumeUploadedAt: response.data.uploadedAt,
          });

          // Check for selected job description
          const { selectedJobDescription: checkSelected } = await chrome.storage.local.get(['selectedJobDescription']);
          if (checkSelected) {
            jobText.textContent = checkSelected;
            window.showTailorSection();
          } else {
            // Show home page after login
            window.showReadySection();
          }
          loadResumeInfo();
          return;
        } else {

        }
      } else {

      }
    } catch (error) {

      // Don't show error to user, just show upload section
    }
    
    // If we get here, no resume found - new account, show upload section
    
    window.showUploadSection();
  }

}

// Show sections - functions are defined in ui.js, but we keep state saving logic here
// The actual UI manipulation is handled by ui.js functions

function showError(message) {
  errorMessage.textContent = message;
  authSection.classList.add('hidden');
  uploadSection.classList.add('hidden');
  readySection.classList.add('hidden');
  tailorSection.classList.add('hidden');
  resultsSection.classList.add('hidden');
  errorSection.classList.remove('hidden');
}

function showInfoBanner(message) {
  const readySectionEl = document.getElementById('ready-section');
  if (!readySectionEl) return;

  const existing = document.getElementById('info-banner');
  if (existing) {
    existing.remove();
  }

  const banner = document.createElement('div');
  banner.id = 'info-banner';
  banner.className = 'info-banner';
  banner.innerHTML = `
    <div class="info-banner-icon">
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <circle cx="12" cy="12" r="10"></circle>
        <line x1="12" y1="8" x2="12" y2="12"></line>
        <line x1="12" y1="16" x2="12.01" y2="16"></line>
      </svg>
    </div>
    <div class="info-banner-text">
      <strong>No generated content yet</strong>
      <span>${message}</span>
    </div>
  `;

  const welcome = readySectionEl.querySelector('.home-welcome');
  if (welcome) {
    readySectionEl.insertBefore(banner, welcome);
  } else {
    readySectionEl.prepend(banner);
  }

  requestAnimationFrame(() => {
    banner.classList.add('show');
  });

  setTimeout(() => {
    banner.classList.remove('show');
    setTimeout(() => banner.remove(), 200);
  }, 5000);
}

// Upload handlers
uploadBox.addEventListener('click', () => {
  resumeFileInput.click();
});

uploadBox.addEventListener('dragover', (e) => {
  e.preventDefault();
  uploadBox.style.borderColor = '#3b82f6';
});

uploadBox.addEventListener('dragleave', () => {
  uploadBox.style.borderColor = '#d1d5db';
});

uploadBox.addEventListener('drop', (e) => {
  e.preventDefault();
  uploadBox.style.borderColor = '#d1d5db';
  const files = e.dataTransfer.files;
  if (files.length > 0) {
    handleFileSelect(files[0]);
  }
});

resumeFileInput.addEventListener('change', (e) => {
  if (e.target.files.length > 0) {
    handleFileSelect(e.target.files[0]);
  }
});

function handleFileSelect(file) {
  if (!file.type.includes('pdf') && !file.type.includes('wordprocessingml')) {
    showUploadStatus('Please select a PDF or DOCX file', 'error');
    return;
  }

  if (file.size > 5 * 1024 * 1024) {
    showUploadStatus('File size must be less than 5MB', 'error');
    return;
  }

  uploadBtn.disabled = false;
  showUploadStatus(`Selected: ${file.name}`, 'success');
}

async function uploadResume() {
  const file = resumeFileInput.files[0];
  if (!file) {
    showUploadStatus('Please select a file first', 'error');
    return;
  }

  // Set operation state
  await chrome.storage.local.set({ operationState: 'uploading' });
  
  uploadBtn.disabled = true;
  showUploadStatus('Uploading...', 'success');

  try {
    const formData = new FormData();
    formData.append('resume', file);

    // Use centralized API config
    const uploadUrl = window.API_CONFIG ? window.API_CONFIG.buildUrl('/upload-resume') : `${getApiBaseUrl()}/upload-resume`;
    const authToken = window.API_CONFIG ? await window.API_CONFIG.getAuthToken() : (await chrome.storage.local.get(['authToken'])).authToken;
    
    // Build headers - DON'T set Content-Type for FormData (browser sets it automatically with boundary)
    // But we MUST include ngrok-skip-browser-warning header
    const headers = {};
    if (authToken) {
      headers['Authorization'] = `Bearer ${authToken}`;
    }
    
    // CRITICAL: Add ngrok skip header - this MUST be present to bypass ngrok warning page
    if (window.API_CONFIG) {
      if (window.API_CONFIG.isNgrokUrl(uploadUrl)) {
      headers['ngrok-skip-browser-warning'] = 'true';
    }
    } else {
      // Fallback: manual check
      if (uploadUrl.includes('ngrok-free.app') || uploadUrl.includes('ngrok-free.dev') || uploadUrl.includes('ngrok.io') || uploadUrl.includes('ngrok')) {
        headers['ngrok-skip-browser-warning'] = 'true';
      }
    }

    const response = await fetch(uploadUrl, {
      method: 'POST',
      headers: headers, // Don't set Content-Type - browser will set it with boundary for FormData
      body: formData,
    });

    // Use centralized response parsing if available
    let data;
    if (window.API_CONFIG) {
      try {
        data = await window.API_CONFIG.parseResponse(response);
      } catch (parseError) {
        // parseResponse throws error for HTML, re-throw it with more context

        throw parseError;
      }
    } else {
      // Fallback: manual check
      const contentType = response.headers.get('content-type');
    if (contentType && contentType.includes('application/json')) {
      data = await response.json();
    } else {
      const text = await response.text();
        
        throw new Error(`API returned HTML instead of JSON. URL: ${uploadUrl}\n\nCheck:\n1. Backend server is running (npm run dev in backend2)\n2. API URL is correct (click gear icon in popup)\n3. Endpoint exists: /api/upload-resume\n4. ngrok is pointing to port 3000 (not 8000)\n5. ngrok-skip-browser-warning header is being sent (check Network tab in browser console)`);
      }
    }

    if (!response.ok) {
      throw new Error(data.error || data.message || 'Upload failed');
    }

    // Standard response format
    if (data.success && data.data.resumeId) {
      // Clear operation state and save resume info
      await chrome.storage.local.set({ 
        resumeId: data.data.resumeId,
        resumeFilename: data.data.filename || 'resume.pdf',
        resumeCloudinaryUrl: data.data.cloudinaryUrl,
        resumeUploadedAt: data.data.uploadedAt,
        operationState: null 
      });
      
      showUploadStatus('Resume uploaded successfully!', 'success');
      setTimeout(() => {
        hideUploadStatus(); // Hide status before showing ready section
        window.showReadySection();
        loadResumeInfo(); // Load and display resume info
        checkForSelectedText();
      }, 1000);
    } else {
      throw new Error('Invalid response format');
    }
  } catch (error) {
    // Clear operation state on error
    await chrome.storage.local.set({ operationState: null });
    showUploadStatus(error.message, 'error');
    uploadBtn.disabled = false;
  }
}

function showUploadStatus(message, type) {
  if (!uploadStatus) return;
  uploadStatus.textContent = message;
  uploadStatus.className = `upload-status ${type}`;
  uploadStatus.classList.remove('hidden');
}

function hideUploadStatus() {
  if (!uploadStatus) return;
  uploadStatus.classList.add('hidden');
}

uploadBtn.addEventListener('click', uploadResume);

// Load and display home page stats
async function loadResumeInfo() {
  try {
    const { authToken } = await chrome.storage.local.get(['authToken']);
    if (!authToken) {
      return; // Not authenticated
    }
    
    // Fetch all resumes to get stats
    const resumesResponse = await window.apiRequest('/resumes?page=1&limit=100');
    const { lastResults } = await chrome.storage.local.get(['lastResults']);

    let totalResumes = 0;
    let totalGenerated = 0;
    let lastGeneratedDate = null;

    if (resumesResponse.success && resumesResponse.data) {
      totalResumes = resumesResponse.data.pagination?.total || resumesResponse.data.resumes?.length || 0;
      
      // Count resumes with tailored content
      const resumes = resumesResponse.data.resumes || [];
      totalGenerated = resumes.filter(r => r.hasTailoredContent).length;

      // Find most recent generated date
      const generatedDates = resumes
        .filter(r => r.currentVersion?.updatedAt)
        .map(r => new Date(r.currentVersion.updatedAt))
        .sort((a, b) => b - a);
      
      if (generatedDates.length > 0) {
        lastGeneratedDate = generatedDates[0];
      } else if (lastResults) {
        // Fallback to lastResults if available
        const lastViewed = await chrome.storage.local.get(['lastViewedAt']);
        if (lastViewed.lastViewedAt) {
          lastGeneratedDate = new Date(lastViewed.lastViewedAt);
        }
      }
    }

    // Update stats display
    const statResumes = document.getElementById('stat-resumes');
    const statGenerated = document.getElementById('stat-generated');

    if (statResumes) {
      statResumes.textContent = totalResumes;
    }
    if (statGenerated) {
      statGenerated.textContent = totalGenerated;
    }
  } catch (error) {

  }
}

// Display resume information in the UI
function displayResumeInfo(filename, cloudinaryUrl, uploadedAt) {
  const resumeFilename = document.getElementById('resume-filename');
  const resumeUploadDate = document.getElementById('resume-upload-date');
  const resumeInfoCard = document.getElementById('resume-info-card');
  
  if (resumeFilename) {
    resumeFilename.textContent = filename;
  }
  
  if (resumeUploadDate && uploadedAt) {
    try {
      const date = new Date(uploadedAt);
      const formattedDate = date.toLocaleDateString('en-US', { 
        year: 'numeric', 
        month: 'short', 
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });
      resumeUploadDate.textContent = `Uploaded: ${formattedDate}`;
    } catch (e) {
      resumeUploadDate.textContent = '';
    }
  }
  
  if (resumeInfoCard) {
    resumeInfoCard.style.display = 'block';
  }
}

// Check for selected text from context menu
// NOTE: This is now called from init() before showing ready section
// This function is kept for backward compatibility but may not be needed
async function checkForSelectedText() {
  const { selectedJobDescription, lastContextMenuClick } = await chrome.storage.local.get(['selectedJobDescription', 'lastContextMenuClick']);
  
  if (selectedJobDescription) {
    // Check if this is a new context menu click (force navigation)
    // If lastContextMenuClick exists and is recent (within last 5 seconds), always navigate
    const shouldForceNavigate = lastContextMenuClick && (Date.now() - lastContextMenuClick < 5000);
    
    // ALWAYS navigate to tailor section when text is selected via context menu
    // This ensures navigation happens even if the same text is selected
    // Force navigation regardless of current section
    await chrome.storage.local.set({
      currentSection: 'tailor',
      operationState: null, // Clear any pending operation
      pendingJobDescription: null, // Clear old pending description
      // Keep lastResults for reference, but don't auto-restore
    });
    
    // Update job text and navigate to tailor section
    if (jobText) {
      jobText.textContent = selectedJobDescription;
    }
    
    // Force navigation to tailor section - this will work even if already on results page
    window.showTailorSection();
    
    // Don't remove selectedJobDescription yet - keep it until generation starts
    // This ensures it's available if the user clicks generate before it's displayed
    
    // Clear the context menu click timestamp after navigation
    if (shouldForceNavigate) {
      await chrome.storage.local.remove(['lastContextMenuClick']);
    }
    
    // Ensure loading is hidden - never show automatically
    if (loading) {
      loading.classList.add('hidden');
    }
    if (tailorBtn) {
      tailorBtn.disabled = false;
    }

  }
}

// Tailor resume - attach listener immediately
if (tailorBtn) {

  tailorBtn.addEventListener('click', async (e) => {

    e.preventDefault();
    e.stopPropagation();
    
    try {

      // Get job description from multiple sources
      let jobDescription = '';
      
      // 1. Try to get from the displayed text element
      if (jobText) {
        jobDescription = jobText.textContent || jobText.innerText || jobText.value || '';
      }
      
      // 2. If empty, try to get from storage (in case it was set but not displayed)
      if (!jobDescription || jobDescription.trim().length === 0) {
        const storage = await chrome.storage.local.get(['selectedJobDescription', 'savedJobDescription']);
        if (storage.selectedJobDescription) {
          jobDescription = storage.selectedJobDescription;
          if (jobText) {
            jobText.textContent = storage.selectedJobDescription;
          }
        } else if (storage.savedJobDescription) {
          jobDescription = storage.savedJobDescription;
          if (jobText) {
            jobText.textContent = storage.savedJobDescription;
          }
        }
      }
      
      // 3. Trim whitespace
      jobDescription = jobDescription.trim();
      
      const { authToken } = await chrome.storage.local.get(['authToken']);
      if (!authToken) {
        if (jobDescription) {
          await chrome.storage.local.set({
            selectedJobDescription: jobDescription,
            currentSection: 'tailor',
          });
        }
        window.showAuthSection();
        return;
      }

      let resumeId = (await chrome.storage.local.get(['resumeId'])).resumeId;

      if (!jobDescription || jobDescription.length === 0) {
        window.showError('Please select a job description by highlighting text on a webpage and right-clicking to choose "On Page CV Tailor to this role"');
        return;
      }
      
      // If no resumeId, try to fetch from API
      if (!resumeId) {

        try {
          const response = await window.apiRequest('/resume');

          if (response.success && response.data && response.data.resumeId) {
            resumeId = response.data.resumeId;

            // Save to storage for future use
            await chrome.storage.local.set({
              resumeId: resumeId,
              resumeFilename: response.data.filename,
              resumeCloudinaryUrl: response.data.cloudinaryUrl,
              resumeUploadedAt: response.data.uploadedAt,
            });
          } else {
            if (jobDescription) {
              await chrome.storage.local.set({ selectedJobDescription: jobDescription });
            }
            window.showUploadSection();
            showUploadStatus('Please upload your resume to continue', 'error');
            return;
          }
        } catch (error) {
          if (jobDescription) {
            await chrome.storage.local.set({ selectedJobDescription: jobDescription });
          }
          window.showUploadSection();
          showUploadStatus('Please upload your resume to continue', 'error');
          return;
        }
      }
      
      // Final check - if still no resumeId, show error
      if (!resumeId) {
        if (jobDescription) {
          await chrome.storage.local.set({ selectedJobDescription: jobDescription });
        }
        window.showUploadSection();
        showUploadStatus('Please upload your resume to continue', 'error');
        return;
      }

      // Set operation state for persistence and clear old results
      // Store jobDescription and generateFreely for potential regeneration
      const generateFreelyToggleBtn = document.getElementById('generate-freely-toggle');
      const generateFreely = generateFreelyToggleBtn ? generateFreelyToggleBtn.checked : false;
      
      // Get custom mode and instructions
      const customModeToggleBtn = document.getElementById('custom-mode-toggle');
      const customMode = customModeToggleBtn ? customModeToggleBtn.checked : false;
      const customInstructionsInputField = document.getElementById('custom-instructions');
      const customInstructions = customMode && customInstructionsInputField ? customInstructionsInputField.value.trim() : '';
      
      // Store generation start time for persistence tracking
      const generationStartTime = Date.now();
      
      // Clear selectedJobDescription from storage since generation is starting
      await chrome.storage.local.remove(['selectedJobDescription']);
      
      await chrome.storage.local.set({ 
        operationState: 'tailoring',
        pendingJobDescription: jobDescription,
        jobDescription: jobDescription, // Store for regeneration
        generateFreely: generateFreely, // Store for regeneration
        customMode: customMode, // Store custom mode
        customInstructions: customInstructions, // Store custom instructions
        currentSection: 'tailor', // Update section to tailor (not results)
        generationStartTime: generationStartTime, // Track when generation started
        // Don't clear lastResults yet - we'll update it after successful generation
      });

      loading.classList.remove('hidden');
      tailorBtn.disabled = true;
      
      // Start rotating messages
      startLoadingMessages();
      
      const startTime = Date.now();
      const apiUrl = getApiBaseUrl() + '/tailor-resume';

      // Create a timeout to detect hanging requests
      const timeoutId = setTimeout(() => {

      }, 10000);
      
      try {
        // Get generate freely and custom instructions from storage (already stored above)
        const { generateFreely: storedGenerateFreely, customMode: storedCustomMode, customInstructions: storedCustomInstructions } = await chrome.storage.local.get(['generateFreely', 'customMode', 'customInstructions']);
        const generateFreely = storedGenerateFreely !== undefined ? storedGenerateFreely : false;
        const customMode = storedCustomMode !== undefined ? storedCustomMode : false;
        const customInstructions = storedCustomInstructions || '';
        
        const response = await window.apiRequest(`/tailor-resume`, {
          method: 'POST',
          body: JSON.stringify({
            resumeId,
            jobDescription,
            generateFreely: generateFreely, // Send toggle value
            customMode: customMode, // Send custom mode flag
            customInstructions: customInstructions, // Send custom instructions if provided
          }),
        });

        clearTimeout(timeoutId);
        
        const duration = Date.now() - startTime;

        // Standard response format
        if (response.success && response.data) {

          await displayResults(response.data);
          
          // Refresh credits display after successful generation
          if (window.loadCredits) {
            await window.loadCredits();
          }
          
              // Clear operation state AFTER displaying results
              if (window.StateManager && typeof window.StateManager.clearGenerationState === 'function') {
                await window.StateManager.clearGenerationState();
              } else {
          await chrome.storage.local.set({ 
            operationState: null,
            pendingJobDescription: null,
            generationStartTime: null, // Clear generation start time
                });
              }
              await chrome.storage.local.set({
            savedJobDescription: jobDescription // Save the job description for this result
          });
          
          window.showResultsSection();

        } else {
          throw new Error(response.error || 'Failed to generate tailored content');
        }
      } catch (error) {
        clearTimeout(timeoutId);
        const duration = Date.now() - startTime;

        // Clear operation state on error
             if (window.StateManager && typeof window.StateManager.clearGenerationState === 'function') {
               await window.StateManager.clearGenerationState();
             } else {
        await chrome.storage.local.set({ 
          operationState: null,
                 pendingJobDescription: null,
          generationStartTime: null, // Clear generation start time
        });
             }
        window.showError(error.message);
      } finally {
        stopLoadingMessages();
        loading.classList.add('hidden');
        tailorBtn.disabled = false;

      }
    } catch (error) {

      window.showError('An unexpected error occurred: ' + error.message);
    }
  });
} else {

  // Try to find it again after a delay
  setTimeout(() => {
    const retryBtn = document.getElementById('tailor-btn');
    if (retryBtn) {

      tailorBtn = retryBtn;
      // Re-attach listener
      tailorBtn.addEventListener('click', async (e) => {
        
        // ... (same handler code)
      });
    } else {

    }
  }, 100);
}

// Display results - wrapper to ensure expand buttons are set up
async function displayResults(data) {
  // Full Resume Preview (backend returns 'fullResume', not 'fullDocument')
  const fullResumeText = data.fullResume || data.fullDocument || '';
  if (fullResumeText && fullResumeText.trim().length > 0) {
    // Check if content is HTML (contains HTML tags)
    const isHTML = /<[a-z][\s\S]*>/i.test(fullResumeText);
    
    if (isHTML) {
      // Store HTML version for rich editor
      fullDocumentContent.dataset.htmlContent = fullResumeText;
      // Convert HTML to plain text for textarea display
      const tempDiv = document.createElement('div');
      tempDiv.innerHTML = fullResumeText;
      const plainText = convertHtmlToPlainText(tempDiv);
      fullDocumentContent.value = plainText;
    } else {
      // Plain text - use as is
    fullDocumentContent.value = fullResumeText;
      fullDocumentContent.dataset.htmlContent = ''; // Clear HTML if it was plain text
    }
  } else {

    fullDocumentContent.value = 'Resume not available';
    fullDocumentContent.dataset.htmlContent = '';
  }

  // Cover Letter
  if (data.coverLetter && data.coverLetter.trim().length > 0) {
    // Check if content is HTML
    const isHTML = /<[a-z][\s\S]*>/i.test(data.coverLetter);
    
    if (isHTML) {
      // Store HTML version for rich editor
      coverLetterContent.dataset.htmlContent = data.coverLetter;
      // Convert HTML to plain text for textarea display
      const tempDiv = document.createElement('div');
      tempDiv.innerHTML = data.coverLetter;
      const plainText = convertHtmlToPlainText(tempDiv);
      coverLetterContent.value = plainText;
    } else {
      // Plain text - use as is
    coverLetterContent.value = data.coverLetter;
      coverLetterContent.dataset.htmlContent = ''; // Clear HTML if it was plain text
    }
  } else {

    coverLetterContent.value = 'Cover letter not available';
    coverLetterContent.dataset.htmlContent = '';
  }

  // Store results for download
  await chrome.storage.local.set({ 
    lastResults: {
      ...data,
      fullResume: fullResumeText, // Ensure fullResume is stored
      fullDocument: fullResumeText // Keep for backward compatibility
    }
  });
  
  // Display quality scores and similarity metrics if available
  if (typeof window.displayQualityScores === 'function' && data.qualityScore && data.similarityMetrics) {
    window.displayQualityScores(data.qualityScore, data.similarityMetrics);
  }

  // Setup regenerate button handler
  const regenerateBtn = document.getElementById('regenerate-btn');
  if (regenerateBtn) {
    regenerateBtn.onclick = async () => {
      await handleRegenerate(data);
    };
  }
  
  // Setup expand buttons after results are displayed
  setTimeout(() => {
    setupExpandButtons();
    // Initialize feedback buttons
    if (window.initFeedbackButtons) {
      window.initFeedbackButtons();
    }
  }, 100);

}

// Handle regenerate button click
async function handleRegenerate(currentData) {
  try {
    const regenerateBtn = document.getElementById('regenerate-btn');
    if (regenerateBtn) {
      regenerateBtn.disabled = true;
      regenerateBtn.innerHTML = `
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="spinning">
          <polyline points="23 4 23 10 17 10"></polyline>
          <polyline points="1 20 1 14 7 14"></polyline>
          <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path>
        </svg>
        <span>Regenerating...</span>
      `;
    }

    // Show loading overlay with rotating messages
    if (loading) {
      loading.classList.remove('hidden');
      // Start regeneration-specific loading messages
      if (typeof window.startRegenerationMessages === 'function') {
        window.startRegenerationMessages();
      } else {
        // Fallback: use regular loading messages
        if (typeof window.startLoadingMessages === 'function') {
          window.startLoadingMessages();
        }
      }
    }

    // Get current data
    const { resumeId } = await chrome.storage.local.get(['resumeId']);
    const { jobDescription, generateFreely } = await chrome.storage.local.get(['jobDescription', 'generateFreely']);
    
    if (!resumeId || !jobDescription) {
      // Try to get from current results
      const storedResults = await chrome.storage.local.get(['lastResults']);
      if (storedResults.lastResults) {
        // Extract from stored results if available
        throw new Error('Please generate a resume first before regenerating');
      } else {
        throw new Error('Missing resume ID or job description');
      }
    }

    // Get additional keywords from current results - filter out noise words
    const allMissingKeywords = currentData.similarityMetrics?.missingKeywords || [];
    const matchedKeywords = currentData.similarityMetrics?.matchedKeywords || [];
    const noiseWords = ['intern', 'posted', 'save', 'share', 'apply', 'days', 'ago', 'united', 'states', 'work', 'home', 'part', 'time', 'hours', 'week', 'authorization', 'required', 'open', 'candidates', 'opt', 'cpt'];
    const missingKeywords = allMissingKeywords.filter(kw => {
      const lower = kw.toLowerCase();
      return !noiseWords.some(noise => lower.includes(noise)) && kw.length > 2;
    }).slice(0, 30); // Limit to top 30 most important
    
    const currentResumeText = fullDocumentContent?.value || '';

    // Call regenerate endpoint
    const response = await window.apiRequest('/regenerate-resume', {
      method: 'POST',
      body: JSON.stringify({
        resumeId,
        jobDescription,
        generateFreely: generateFreely === true || generateFreely === 'true',
        missingKeywords,
        matchedKeywords, // Pass matched keywords to preserve them
        currentResumeText,
      }),
    });

    if (response.success && response.data) {
      // Update results with regenerated content
      await displayResults(response.data);
      
      // Refresh credits display after successful regeneration
      if (window.loadCredits) {
        await window.loadCredits();
      }
      
      // Show success message
      if (window.showToast) {
        window.showToast('Resume regenerated successfully! Match score improved.', 'success');
      }

      // Hide loading
      if (loading) {
        loading.classList.add('hidden');
      }

      // Reset button
      if (regenerateBtn) {
        regenerateBtn.disabled = false;
        regenerateBtn.innerHTML = `
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <polyline points="23 4 23 10 17 10"></polyline>
            <polyline points="1 20 1 14 7 14"></polyline>
            <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path>
          </svg>
          <span>Regenerate</span>
        `;
      }
    } else {
      throw new Error(response.error || 'Failed to regenerate resume');
    }
  } catch (error) {

    // Check if it's a credit error (402 Payment Required)
    if (error.status === 402 || (error.message && error.message.includes('credits'))) {
      // Show payment modal
      if (window.openPaymentModal) {
        window.openPaymentModal();
      }
      // Show error message
      if (window.showToast) {
        window.showToast(error.message || 'No credits available. Please purchase credits to continue.', 'error');
      }
    } else {
      if (window.showToast) {
        window.showToast('Failed to regenerate resume: ' + error.message, 'error');
      }
    }
    
    // Hide loading
    if (loading) {
      loading.classList.add('hidden');
    }

    // Reset button
    const regenerateBtn = document.getElementById('regenerate-btn');
    if (regenerateBtn) {
      regenerateBtn.disabled = false;
      regenerateBtn.innerHTML = `
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <polyline points="23 4 23 10 17 10"></polyline>
          <polyline points="1 20 1 14 7 14"></polyline>
          <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path>
        </svg>
        <span>Regenerate</span>
      `;
    }
  }
}

// Copy buttons (updated for icon buttons with clipboard fallback)
document.querySelectorAll('.btn-copy').forEach(btn => {
  btn.addEventListener('click', (e) => {
    e.stopPropagation();
    // Get target from button, not event target (in case icon is clicked)
    const target = btn.getAttribute('data-target') || btn.closest('.btn-copy')?.getAttribute('data-target');
    let text = '';

    switch (target) {
      case 'full-document':
        text = fullDocumentContent?.value || '';
        break;
      case 'cover-letter':
        text = coverLetterContent?.value || '';
        break;
    }

    if (!text) return;

    const showCopiedFeedback = () => {
      const originalHTML = btn.innerHTML;
      btn.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"></polyline></svg>';
      btn.style.color = '#10b981';
      setTimeout(() => {
        btn.innerHTML = originalHTML;
        btn.style.color = '';
      }, 2000);
    };

    // Prefer modern clipboard API when available
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(() => {
        showCopiedFeedback();
    }).catch(err => {

        try {
          const textarea = document.createElement('textarea');
          textarea.value = text;
          textarea.style.position = 'fixed';
          textarea.style.opacity = '0';
          document.body.appendChild(textarea);
          textarea.focus();
          textarea.select();
          const successful = document.execCommand('copy');
          document.body.removeChild(textarea);
          if (successful) {
            showCopiedFeedback();
          }
        } catch (fallbackErr) {

        }
      });
    } else {
      // Fallback for environments without navigator.clipboard
      try {
        const textarea = document.createElement('textarea');
        textarea.value = text;
        textarea.style.position = 'fixed';
        textarea.style.opacity = '0';
        document.body.appendChild(textarea);
        textarea.focus();
        textarea.select();
        const successful = document.execCommand('copy');
        document.body.removeChild(textarea);
        if (successful) {
          showCopiedFeedback();
        }
      } catch (err) {

      }
    }
  });
});

// Download dropdown functionality
const downloadBtn = document.querySelector('.btn-download');
const downloadDropdown = document.querySelector('.download-dropdown-menu');
const downloadOptions = document.querySelectorAll('.download-option');

if (downloadBtn && downloadDropdown) {
  // Toggle dropdown
  downloadBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    downloadDropdown.classList.toggle('hidden');
  });
  
  // Close dropdown when clicking outside
  document.addEventListener('click', (e) => {
    if (!downloadBtn.contains(e.target) && !downloadDropdown.contains(e.target)) {
      downloadDropdown.classList.add('hidden');
  }
  });

  // Handle download option clicks
  downloadOptions.forEach(option => {
    option.addEventListener('click', async (e) => {
      e.stopPropagation();
      const format = option.getAttribute('data-format');
      
      // Don't close dropdown immediately - keep it open to show loading state
      // downloadDropdown.classList.add('hidden');
      
      // Show loading state on the clicked download option button
      const originalHTML = option.innerHTML;
      const originalDisabled = option.disabled;
      option.classList.add('downloading');
      option.disabled = true;
      
      // Replace content with loading spinner (blue)
      option.innerHTML = `
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="download-spinner" style="color: #3b82f6;">
          <circle cx="12" cy="12" r="10" stroke-opacity="0.25" stroke="#3b82f6"></circle>
          <path d="M12 2a10 10 0 0 1 10 10" stroke-linecap="round" stroke="#3b82f6"></path>
        </svg>
        <span style="color: #3b82f6; font-weight: 600;">Downloading...</span>
      `;
      
      // Also show loading on main download button (blue spinner)
      if (downloadBtn) {
        downloadBtn.classList.add('loading');
        downloadBtn.disabled = true;
        const btnOriginalHTML = downloadBtn.innerHTML;
        downloadBtn.innerHTML = `
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#3b82f6" stroke-width="2" style="animation: spin 0.8s linear infinite;">
            <circle cx="12" cy="12" r="10" stroke-opacity="0.25"></circle>
            <path d="M12 2a10 10 0 0 1 10 10" stroke-linecap="round"></path>
          </svg>
        `;
        
        try {
          await downloadTailoredResume(format);
          // Close dropdown after successful download
          downloadDropdown.classList.add('hidden');
        } catch (error) {

          // Error is already shown by DownloadHandler
          // Keep dropdown open on error so user can retry
        } finally {
          // Remove loading state from main download button
          downloadBtn.classList.remove('loading');
          downloadBtn.disabled = false;
          downloadBtn.innerHTML = btnOriginalHTML;
        }
      } else {
        try {
          await downloadTailoredResume(format);
          // Close dropdown after successful download
          downloadDropdown.classList.add('hidden');
        } catch (error) {

        }
      }
      
      // Remove loading state from option button
      option.classList.remove('downloading');
      option.disabled = originalDisabled;
      option.innerHTML = originalHTML;
    });
  });
}

// Note: Save functionality removed - download always uses current textarea content

// Download function (shared for both formats) - now uses DownloadHandler
async function downloadTailoredResume(format) {
  await window.DownloadHandler.downloadTailoredResume(format);
}

// Download buttons are now handled by the dropdown (see above)

// New tailor button
newTailorBtn.addEventListener('click', async () => {
  // Clear saved results state and any pending operations
  await chrome.storage.local.set({ 
    currentSection: 'ready',
    lastResults: null,
    lastViewedAt: null,
    savedJobDescription: null,
    operationState: null,
    pendingJobDescription: null
  });
  window.showReadySection();
  loadResumeInfo(); // Load and display resume info
  checkForSelectedText();
});

// Listen for messages from popup-injector to force check selected text
// This ensures navigation happens even when the same text is selected
window.addEventListener('message', async (event) => {
  // Accept messages from any origin (popup-injector runs in page context)
  if (event.data && event.data.action === 'forceCheckSelectedText') {

    // Always check and navigate to tailor section if text is selected
    // Use a small delay to ensure storage is updated
    setTimeout(async () => {
      await checkForSelectedText();
    }, 50);
  }
});

// Check for selected text when popup becomes visible
// This handles the case when popup is toggled from hidden to visible
document.addEventListener('visibilitychange', async () => {
  if (!document.hidden) {
    // Popup became visible - check for selected text (with small delay to ensure storage is updated)
    setTimeout(async () => {
      await checkForSelectedText();
    }, 100);
  }
});

// Poll for context menu clicks when popup is visible
// This ensures we catch context menu clicks even if messages don't get through
let lastCheckedTimestamp = 0;
let contextMenuPollInterval = null;

function startContextMenuPolling() {
  if (contextMenuPollInterval) return; // Already polling
  
  contextMenuPollInterval = setInterval(async () => {
    if (document.hidden) return; // Don't poll when hidden
    
    try {
      const { lastContextMenuClick } = await chrome.storage.local.get(['lastContextMenuClick']);
      
      // If there's a new context menu click (timestamp changed), force check
      if (lastContextMenuClick && lastContextMenuClick !== lastCheckedTimestamp) {

        lastCheckedTimestamp = lastContextMenuClick;
        await checkForSelectedText();
      }
    } catch (error) {

    }
  }, 200); // Check every 200ms
}

function stopContextMenuPolling() {
  if (contextMenuPollInterval) {
    clearInterval(contextMenuPollInterval);
    contextMenuPollInterval = null;
  }
}

// Start polling when popup is visible
if (!document.hidden) {
  startContextMenuPolling();
}

document.addEventListener('visibilitychange', () => {
  if (document.hidden) {
    stopContextMenuPolling();
  } else {
    startContextMenuPolling();
    // Also check immediately when becoming visible
    setTimeout(async () => {
      await checkForSelectedText();
    }, 100);
  }
});

// Retry button
retryBtn.addEventListener('click', () => {
  init();
});

// Initialize expanded rich text editor
function initExpandedEditor() {
  if (!expandedEditorText || !expandedEditorToolbar) return;

  // Setup toolbar buttons
  const toolbarButtons = expandedEditorToolbar.querySelectorAll('.toolbar-btn');
  
  // Store selection before button click (to prevent loss)
  let savedSelection = null;
  
  // Save selection when mouse enters button area
  toolbarButtons.forEach(btn => {
    btn.addEventListener('mousedown', (e) => {
      // Save selection BEFORE click causes it to be lost
      const selection = window.getSelection();
      if (selection && selection.rangeCount > 0) {
        const range = selection.getRangeAt(0);
        // Only save if selection is in the editor
        if (expandedEditorText && expandedEditorText.contains(range.commonAncestorContainer)) {
          savedSelection = range.cloneRange();
        } else {
          savedSelection = null;
        }
      } else {
        savedSelection = null;
      }
    });
    
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      
      const command = btn.dataset.command;
      const value = btn.dataset.value || null;
      
      if (!command) return;
      
      // Immediately focus the editor
      if (expandedEditorText) {
        expandedEditorText.focus();
        
        const selection = window.getSelection();
        let range = null;
        
        // Restore saved selection if available
        if (savedSelection) {
          try {
            selection.removeAllRanges();
            selection.addRange(savedSelection);
            range = savedSelection;
            savedSelection = null; // Clear after use
          } catch (err) {

            savedSelection = null;
          }
        }
        
        // If no saved selection, get current selection
        if (!range && selection && selection.rangeCount > 0) {
          range = selection.getRangeAt(0);
          if (!expandedEditorText.contains(range.commonAncestorContainer)) {
            range = null;
          }
        }
        
        // If still no selection, create one
        if (!range) {
          range = document.createRange();
          
          // Find last text node
          const walker = document.createTreeWalker(
            expandedEditorText,
            NodeFilter.SHOW_TEXT,
            null
          );
          
          let textNode = null;
          let node;
          while (node = walker.nextNode()) {
            textNode = node;
          }
          
          if (textNode) {
            const textLength = textNode.textContent.length;
            // For formatting commands, try to select word at cursor
            if (command === 'bold' || command === 'italic' || command === 'underline') {
              const text = textNode.textContent;
              let start = textLength;
              let end = textLength;
              
              // Find word boundaries
              while (start > 0 && /[\w\u00C0-\u017F]/.test(text[start - 1])) start--;
              while (end < text.length && /[\w\u00C0-\u017F]/.test(text[end])) end++;
              
              if (start < end) {
                range.setStart(textNode, start);
                range.setEnd(textNode, end);
              } else {
                range.setStart(textNode, textLength);
                range.setEnd(textNode, textLength);
              }
            } else {
              range.setStart(textNode, textLength);
              range.setEnd(textNode, textLength);
            }
          } else {
            // No text nodes, create one
            const newTextNode = document.createTextNode('\u200B');
            expandedEditorText.appendChild(newTextNode);
            range.setStart(newTextNode, 0);
            range.setEnd(newTextNode, 0);
          }
          
          selection.removeAllRanges();
          selection.addRange(range);
        }
      }
      
      // Execute command immediately (synchronously)
      try {
        let success = false;
        
        if (value !== null && value !== undefined) {
          success = document.execCommand(command, false, value);
        } else {
          success = document.execCommand(command, false);
        }
        
        if (!success) {

        }
        
        // Update toolbar state
        setTimeout(() => {
          updateToolbarState();
        }, 10);
        
        // Keep editor focused
        if (expandedEditorText) {
          expandedEditorText.focus();
        }
      } catch (err) {

      }
    });
  });

  // Update toolbar button states based on selection
  function updateToolbarState() {
    if (!expandedEditorText || expandedEditorText !== document.activeElement) {
      return; // Editor not focused, don't update
    }
    
    toolbarButtons.forEach(btn => {
      const command = btn.dataset.command;
      btn.classList.remove('active');
      
      try {
        if (command === 'bold' && document.queryCommandState('bold')) {
          btn.classList.add('active');
        } else if (command === 'italic' && document.queryCommandState('italic')) {
          btn.classList.add('active');
        } else if (command === 'underline' && document.queryCommandState('underline')) {
          btn.classList.add('active');
        } else if (command === 'formatBlock') {
          const formatValue = btn.dataset.value;
          const currentFormat = document.queryCommandValue('formatBlock');
          if (currentFormat === formatValue) {
            btn.classList.add('active');
          }
        } else if (command === 'justifyLeft' && document.queryCommandState('justifyLeft')) {
          btn.classList.add('active');
        } else if (command === 'justifyCenter' && document.queryCommandState('justifyCenter')) {
          btn.classList.add('active');
        }
      } catch (e) {
        // Some commands might not support queryCommandState

      }
    });
  }

  // Update toolbar on selection change
  if (expandedEditorText) {
    expandedEditorText.addEventListener('mouseup', updateToolbarState);
    expandedEditorText.addEventListener('keyup', updateToolbarState);
    document.addEventListener('selectionchange', () => {
      if (expandedEditorText.contains(document.activeElement)) {
        updateToolbarState();
      }
    });
  }
}

// Expand button handlers - set up after DOM is ready
function setupExpandButtons() {

  const expandResumeBtn = document.getElementById('expand-resume-btn');
  const expandCoverLetterBtn = document.getElementById('expand-cover-letter-btn');

  if (expandResumeBtn) {
    // Remove all existing listeners by cloning
    const newResumeBtn = expandResumeBtn.cloneNode(true);
    expandResumeBtn.parentNode.replaceChild(newResumeBtn, expandResumeBtn);
    
    newResumeBtn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();

      openExpandedEditor('resume');
    });

  } else {

  }

  if (expandCoverLetterBtn) {
    // Remove all existing listeners by cloning
    const newCoverBtn = expandCoverLetterBtn.cloneNode(true);
    expandCoverLetterBtn.parentNode.replaceChild(newCoverBtn, expandCoverLetterBtn);
    
    newCoverBtn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();

      openExpandedEditor('cover-letter');
    });

  } else {

  }
}

function openExpandedEditor(target) {

  if (!expandedEditorOverlay) {

    return;
  }
  
  if (!expandedEditorText) {

    return;
  }

  // Initialize editor if not already done
  if (!expandedEditorToolbar || !expandedEditorToolbar.querySelector('.toolbar-btn')?.hasAttribute('data-initialized')) {

    initExpandedEditor();
    const firstBtn = expandedEditorToolbar?.querySelector('.toolbar-btn');
    if (firstBtn) firstBtn.setAttribute('data-initialized', 'true');
  }

  currentEditorTarget = target;
  
  // Get content from textarea
  let content = '';
  let htmlContent = '';
  
  if (target === 'resume' && fullDocumentContent) {
    content = fullDocumentContent.value || '';
    htmlContent = fullDocumentContent.dataset.htmlContent || '';
    expandedEditorTitle.textContent = 'Edit Resume';

  } else if (target === 'cover-letter' && coverLetterContent) {
    content = coverLetterContent.value || '';
    htmlContent = coverLetterContent.dataset.htmlContent || '';
    expandedEditorTitle.textContent = 'Edit Cover Letter';

  }

  // If we have HTML content stored, use it; otherwise convert plain text to HTML
  if (htmlContent && htmlContent.trim()) {

    expandedEditorText.innerHTML = htmlContent;
  } else if (content && content.trim()) {

    // Convert plain text to HTML (preserve line breaks)
    const convertedHtml = content
      .replace(/\n\n+/g, '</p><p>')
      .replace(/\n/g, '<br>');
    expandedEditorText.innerHTML = convertedHtml ? `<p>${convertedHtml}</p>` : '<p><br></p>';
  } else {

    expandedEditorText.innerHTML = '<p><br></p>';
  }

  // Show overlay

  expandedEditorOverlay.classList.remove('hidden');
  
  // Focus editor
  setTimeout(() => {
    if (expandedEditorText) {
      expandedEditorText.focus();
      // Move cursor to end
      try {
        const range = document.createRange();
        range.selectNodeContents(expandedEditorText);
        range.collapse(false);
        const selection = window.getSelection();
        if (selection) {
          selection.removeAllRanges();
          selection.addRange(range);
        }
      } catch (e) {

      }
    }
  }, 150);
}

function closeExpandedEditor(save = false) {
  if (!expandedEditorOverlay || !expandedEditorText || !currentEditorTarget) return;

  if (save) {
    // Get HTML content from contentEditable (this is the source of truth with formatting)
    const htmlContent = expandedEditorText.innerHTML;
    
    // Convert HTML to plain text for display in read-only textarea
    const tempDiv = document.createElement('div');
    tempDiv.innerHTML = htmlContent;
    
    // Convert to text with line breaks (for read-only display)
    let textContent = '';
    const paragraphs = tempDiv.querySelectorAll('p');
    
    if (paragraphs.length > 0) {
      paragraphs.forEach((p, index) => {
        if (index > 0) textContent += '\n\n';
        const brReplaced = p.innerHTML.replace(/<br\s*\/?>/gi, '\n');
        const textOnly = brReplaced.replace(/<[^>]*>/g, '');
        textContent += textOnly;
      });
    } else {
      const brReplaced = htmlContent.replace(/<br\s*\/?>/gi, '\n');
      textContent = brReplaced.replace(/<[^>]*>/g, '');
    }
    
    textContent = textContent.replace(/\n{3,}/g, '\n\n').trim();

    // Save HTML content (with formatting) to dataset - this is what gets downloaded
    // Save plain text to textarea value (for read-only display)
    if (currentEditorTarget === 'resume' && fullDocumentContent) {
      fullDocumentContent.value = textContent; // Plain text for display
      fullDocumentContent.dataset.htmlContent = htmlContent; // HTML with formatting for download
    } else if (currentEditorTarget === 'cover-letter' && coverLetterContent) {
      coverLetterContent.value = textContent; // Plain text for display
      coverLetterContent.dataset.htmlContent = htmlContent; // HTML with formatting for download
    }

  }

  expandedEditorOverlay.classList.add('hidden');
  currentEditorTarget = null;
}

// Close button handlers
if (expandedEditorClose) {
  expandedEditorClose.addEventListener('click', () => {
    closeExpandedEditor(false);
  });
}

if (expandedEditorCancel) {
  expandedEditorCancel.addEventListener('click', () => {
    closeExpandedEditor(false);
  });
}

if (expandedEditorSave) {
  expandedEditorSave.addEventListener('click', () => {
    closeExpandedEditor(true);
  });
}

// Close on ESC key
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && expandedEditorOverlay && !expandedEditorOverlay.classList.contains('hidden')) {
    closeExpandedEditor(false);
  }
});

// Close on overlay background click
if (expandedEditorOverlay) {
  expandedEditorOverlay.addEventListener('click', (e) => {
    if (e.target === expandedEditorOverlay) {
      closeExpandedEditor(false);
    }
  });
}

// Initialize editor and buttons on page load
function initializeEditor() {
  setupExpandButtons();
  initExpandedEditor();
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initializeEditor);
} else {
  initializeEditor();
}

// Verify button exists and event listeners are attached

// Test button click programmatically (for debugging)
if (tailorBtn) {
  // Store in window for debugging
  window.debugTailorBtn = tailorBtn;
}

// Menu toggle and handlers
const menuToggleBtn = document.getElementById('menu-toggle-btn');
const menuDropdown = document.getElementById('menu-dropdown');
const menuHome = document.getElementById('menu-home');
const menuLastGenerated = document.getElementById('menu-last-generated');
const menuSettings = document.getElementById('menu-settings');

if (menuToggleBtn && menuDropdown) {
  menuToggleBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    menuDropdown.classList.toggle('hidden');
  });
  
  // Close dropdown when clicking outside
  document.addEventListener('click', (e) => {
    if (!menuToggleBtn.contains(e.target) && !menuDropdown.contains(e.target)) {
      menuDropdown.classList.add('hidden');
    }
  });
}

// Home menu item - go to ready section (home page after login)
if (menuHome) {
  menuHome.addEventListener('click', async (e) => {
    e.preventDefault();
    menuDropdown.classList.add('hidden');
    
    // Check if user has resume, if yes show ready section, otherwise show upload
    const { resumeId } = await chrome.storage.local.get(['resumeId']);
    if (resumeId) {
      window.showReadySection();
      if (typeof loadResumeInfo === 'function') {
        loadResumeInfo();
      }
    } else {
      // Try to fetch default resume
      try {
        const response = await window.apiRequest('/resume');
        if (response.success && response.data && response.data.resumeId) {
          await chrome.storage.local.set({
            resumeId: response.data.resumeId,
            resumeFilename: response.data.filename,
            resumeCloudinaryUrl: response.data.cloudinaryUrl,
            resumeUploadedAt: response.data.uploadedAt,
          });
          window.showReadySection();
          if (typeof loadResumeInfo === 'function') {
            loadResumeInfo();
          }
        } else {
    window.showUploadSection();
        }
      } catch (error) {

        window.showUploadSection();
      }
    }
  });
}

// Home page action buttons
const homeGenerateBtn = document.getElementById('home-generate-btn');
const homeSettingsBtn = document.getElementById('home-settings-btn');

if (homeGenerateBtn) {
  homeGenerateBtn.addEventListener('click', () => {
    // Check for selected text first
    if (typeof checkForSelectedText === 'function') {
      checkForSelectedText();
    }
    // If no selected text, show tailor section with instructions
    setTimeout(() => {
      const jobText = document.getElementById('job-text');
      if (!jobText || !jobText.textContent || jobText.textContent.trim().length === 0) {
        window.showTailorSection();
      }
    }, 100);
  });
}

if (homeSettingsBtn) {
  homeSettingsBtn.addEventListener('click', () => {
    window.showSettingsSection();
  });
}

// Last Generated Content menu item - go to results section
if (menuLastGenerated) {
  menuLastGenerated.addEventListener('click', async (e) => {
    e.preventDefault();
    menuDropdown.classList.add('hidden');
    
    // Check if there are saved results
    const { lastResults } = await chrome.storage.local.get(['lastResults']);
    if (lastResults) {
      // Restore and display results
      if (typeof displayResults === 'function') {
        await displayResults(lastResults);
      }
      window.showResultsSection();
    } else {
      // No results found, show a friendly banner on the home screen
      const { resumeId } = await chrome.storage.local.get(['resumeId']);
      if (resumeId) {
        window.showReadySection();
        showInfoBanner('Create your first tailored resume to see results here.');
      } else {
        window.showUploadSection();
      }
    }
  });
}

// Settings menu item
if (menuSettings) {
  menuSettings.addEventListener('click', (e) => {
    e.preventDefault();
    menuDropdown.classList.add('hidden');
    window.showSettingsSection(); // Show settings section in popup
  });
}

// Settings section handlers
const settingsBackBtn = document.getElementById('settings-back-btn');
if (settingsBackBtn) {
  settingsBackBtn.addEventListener('click', async () => {
    // Go back to previous section or ready section
    const { resumeId } = await chrome.storage.local.get(['resumeId']);
    if (resumeId) {
      window.showReadySection();
      if (typeof loadResumeInfo === 'function') {
        loadResumeInfo();
      }
    } else {
    window.showUploadSection();
    }
  });
}

// Download resume button handler
const downloadResumeBtn = document.getElementById('download-resume-btn');
if (downloadResumeBtn) {
  downloadResumeBtn.addEventListener('click', async () => {
    try {
      const { resumeCloudinaryUrl, resumeFilename } = await chrome.storage.local.get([
        'resumeCloudinaryUrl', 
        'resumeFilename'
      ]);
      
      if (!resumeCloudinaryUrl) {
        // Try to fetch from API
        const response = await window.apiRequest('/resume');
        if (response.success && response.data.cloudinaryUrl) {
          const url = response.data.cloudinaryUrl;
          const filename = response.data.filename || 'resume.pdf';
          // Download from Cloudinary URL
          window.open(url, '_blank');
        } else {
          window.showError('Resume URL not found');
        }
        return;
      }
      
      // Download from Cloudinary URL
      const filename = resumeFilename || 'resume.pdf';
      window.open(resumeCloudinaryUrl, '_blank');
      
    } catch (error) {

      window.showError('Failed to download resume: ' + error.message);
    }
  });
}

// Close success status card button handler
const closeSuccessBtn = document.getElementById('close-success-btn');
if (closeSuccessBtn) {
  closeSuccessBtn.addEventListener('click', () => {
    const successStatusCard = document.getElementById('success-status-card');
    if (successStatusCard) {
      successStatusCard.style.display = 'none';
    }
  });
}

// Setup authentication handlers
if (typeof window.setupAuthHandlers === 'function') {
  window.setupAuthHandlers();
}

// Loading messages rotation with AI-themed messages
let loadingMessageInterval = null;
const loadingMessages = [
  { main: 'Thinking...', sub: 'Analyzing your resume and job description' },
  { main: 'Scanning...', sub: 'Reading every line of the job description' },
  { main: 'Analyzing...', sub: 'Extracting keywords, skills, and requirements' },
  { main: 'Matching...', sub: 'Aligning your experience with the role' },
  { main: 'Structuring...', sub: 'Organizing sections for clarity and impact' },
  { main: 'Checking ATS...', sub: 'Optimizing for applicant tracking systems' },
  { main: 'Generating...', sub: 'Drafting tailored resume content' },
  { main: 'Reviewing...', sub: 'Ensuring tone, metrics, and action verbs fit' },
  { main: 'Writing...', sub: 'Crafting your professional cover letter' },
  { main: 'Finalizing...', sub: 'Polishing and formatting documents' },
];

// Regeneration-specific messages
const regenerationMessages = [
  { main: 'Enhancing...', sub: 'Reviewing your current resume and improvements' },
  { main: 'Integrating...', sub: 'Adding additional keywords naturally' },
  { main: 'Optimizing...', sub: 'Improving keyword alignment and flow' },
  { main: 'Refining...', sub: 'Making content more targeted and relevant' },
  { main: 'Polishing...', sub: 'Ensuring natural, professional language' },
  { main: 'Finalizing...', sub: 'Preparing your enhanced resume' },
];

function startLoadingMessages() {
  const mainText = document.getElementById('loading-main-text');
  const subText = document.getElementById('loading-sub-text');
  if (!mainText || !subText) return;
  
  let messageIndex = 0;
  mainText.textContent = loadingMessages[0].main;
  subText.textContent = loadingMessages[0].sub;
  
  loadingMessageInterval = setInterval(() => {
    messageIndex = (messageIndex + 1) % loadingMessages.length;
    const message = loadingMessages[messageIndex];
    
    // Fade out
    mainText.classList.add('fade-out');
    subText.classList.add('fade-out');
    
    setTimeout(() => {
      mainText.textContent = message.main;
      subText.textContent = message.sub;
      mainText.classList.remove('fade-out');
      subText.classList.remove('fade-out');
      mainText.classList.add('fade-in');
      subText.classList.add('fade-in');
      
      setTimeout(() => {
        mainText.classList.remove('fade-in');
        subText.classList.remove('fade-in');
      }, 250);
    }, 250);
  }, 3500); // Change message every 3.5 seconds (slower, more readable)
}

function stopLoadingMessages() {
  if (loadingMessageInterval) {
    clearInterval(loadingMessageInterval);
    loadingMessageInterval = null;
  }
  
  const mainText = document.getElementById('loading-main-text');
  const subText = document.getElementById('loading-sub-text');
  if (mainText && subText) {
    mainText.textContent = 'Generating your tailored resume content...';
    subText.textContent = '';
    mainText.classList.remove('fade-out', 'fade-in');
    subText.classList.remove('fade-out', 'fade-in');
  }
}

// Start regeneration-specific loading messages
window.startRegenerationMessages = function() {
  const mainText = document.getElementById('loading-main-text');
  const subText = document.getElementById('loading-sub-text');
  if (!mainText || !subText) return;
  
  // Stop any existing messages
  stopLoadingMessages();
  
  let messageIndex = 0;
  mainText.textContent = regenerationMessages[0].main;
  subText.textContent = regenerationMessages[0].sub;
  
  loadingMessageInterval = setInterval(() => {
    messageIndex = (messageIndex + 1) % regenerationMessages.length;
    const message = regenerationMessages[messageIndex];
    
    // Fade out
    mainText.classList.add('fade-out');
    subText.classList.add('fade-out');
    
    setTimeout(() => {
      mainText.textContent = message.main;
      subText.textContent = message.sub;
      mainText.classList.remove('fade-out');
      subText.classList.remove('fade-out');
      mainText.classList.add('fade-in');
      subText.classList.add('fade-in');
      
      setTimeout(() => {
        mainText.classList.remove('fade-in');
        subText.classList.remove('fade-in');
      }, 250);
    }, 250);
  }, 3500); // Change message every 3.5 seconds
};

// Auto-save edited content (debounced)
let saveTimeout = null;
function autoSaveContent() {
  if (saveTimeout) {
    clearTimeout(saveTimeout);
  }
  
  saveTimeout = setTimeout(async () => {
    if (!fullDocumentContent || !coverLetterContent) return;
    
    const resumeText = fullDocumentContent.value;
    const coverLetter = coverLetterContent.value;
    
    if (!resumeText && !coverLetter) return;
    
    const { resumeId, lastResults } = await chrome.storage.local.get(['resumeId', 'lastResults']);
    if (!resumeId || !lastResults) return;
    
    // Only save if content has changed
    const hasChanges = resumeText !== (lastResults.fullResume || lastResults.fullDocument || '') ||
                       coverLetter !== (lastResults.coverLetter || '');
    
    if (hasChanges) {
      try {
        // Save to localStorage first (fast)
        await chrome.storage.local.set({
          lastResults: {
            ...lastResults,
            fullResume: resumeText,
            fullDocument: resumeText,
            coverLetter: coverLetter,
          },
        });
        
        // Then save to database (async, don't wait)
        window.apiRequest('/update-tailored-content', {
          method: 'POST',
          body: JSON.stringify({
            resumeId,
            tailoredResumeText: resumeText,
            coverLetter: coverLetter,
          }),
        }).catch(err => {

          // Don't show error to user - it's background save
        });
      } catch (error) {

      }
    }
  }, 2000); // Save 2 seconds after user stops typing
}

// Note: Textareas are now read-only, so no auto-save listeners needed
// Content is only saved when user clicks "Save Changes" in the expanded editor
// if (fullDocumentContent) {
//   fullDocumentContent.addEventListener('input', autoSaveContent);
// }
// if (coverLetterContent) {
//   coverLetterContent.addEventListener('input', autoSaveContent);
// }

// Settings button already handled above

// Load saved content when popup opens
async function loadSavedContent() {
  try {
    const { lastResults, resumeId } = await chrome.storage.local.get(['lastResults', 'resumeId']);
    
    if (lastResults && resumeId) {
      // Load saved content into textareas
      if (fullDocumentContent && lastResults.fullResume) {
        fullDocumentContent.value = lastResults.fullResume;
      } else if (fullDocumentContent && lastResults.fullDocument) {
        fullDocumentContent.value = lastResults.fullDocument;
      }
      
      if (coverLetterContent && lastResults.coverLetter) {
        coverLetterContent.value = lastResults.coverLetter;
      }
    }
  } catch (error) {

  }
}

// Mode toggles (100% Match vs Custom) - make them behave like radio buttons
const generateFreelyToggle = document.getElementById('generate-freely-toggle');
const customModeToggle = document.getElementById('custom-mode-toggle');
const customInstructionsContainer = document.getElementById('custom-instructions-container');
const customInstructionsInput = document.getElementById('custom-instructions');

if (customModeToggle && customInstructionsContainer) {
  customModeToggle.addEventListener('change', (e) => {
    const checked = e.target.checked;

    if (checked) {
      // Turn off 100% Match when custom is on
      if (generateFreelyToggle) {
        generateFreelyToggle.checked = false;
      }

      customInstructionsContainer.classList.remove('hidden');
      if (customInstructionsInput) {
        customInstructionsInput.focus();
      }
    } else {
      customInstructionsContainer.classList.add('hidden');
      if (customInstructionsInput) {
        customInstructionsInput.value = '';
      }
    }
  });
}

if (generateFreelyToggle && customModeToggle) {
  generateFreelyToggle.addEventListener('change', (e) => {
    const checked = e.target.checked;

    if (checked) {
      // Turn off custom mode when 100% Match is on
      customModeToggle.checked = false;
      if (customInstructionsContainer) {
        customInstructionsContainer.classList.add('hidden');
      }
      if (customInstructionsInput) {
        customInstructionsInput.value = '';
      }
    }
  });
}

// Initialize on load
init();

// Load saved content after init
setTimeout(loadSavedContent, 500);

// Close functionality for iframe mode
// The close button is handled by popup-injector.js outside the iframe
// We just need to send close messages when needed
if (window.self !== window.top) {
  // We're in an iframe - expose close function for internal use if needed
  window.closePopup = () => {
    window.parent.postMessage({ action: 'closePopup' }, '*');
  };
}

// Keyboard shortcuts
document.addEventListener('keydown', (e) => {
  // ESC to close popup (only if in iframe mode)
  if (e.key === 'Escape' && window.self !== window.top) {
    window.closePopup();
    e.preventDefault();
  }
  
  // Ctrl/Cmd + Enter to submit forms (if focus is on input)
  if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
    const activeElement = document.activeElement;
    if (activeElement && (activeElement.tagName === 'INPUT' || activeElement.tagName === 'TEXTAREA')) {
      // Find the nearest form or submit button
      const form = activeElement.closest('form');
      if (form) {
        const submitBtn = form.querySelector('button[type="submit"]');
        if (submitBtn && !submitBtn.disabled) {
          submitBtn.click();
          e.preventDefault();
        }
      }
    }
  }
});

// Listen for storage changes (when context menu is used)
chrome.storage.onChanged.addListener((changes) => {
  if (changes.selectedJobDescription && changes.selectedJobDescription.newValue) {
    jobText.textContent = changes.selectedJobDescription.newValue;
    window.showTailorSection();
    
    // Ensure loading is hidden - never show automatically
    if (loading) {
      loading.classList.add('hidden');
    }
    if (tailorBtn) {
      tailorBtn.disabled = false;
    }
  }
});
